<?php

use core\App;
use core\Utils;
use core\SessionUtils;
use core\RoleUtils;


         App::getRouter()->setDefaultRoute('LandingPageLoad'); #default action


App::getRouter()->setLoginRoute('login'); #action to forward if no permissions

Utils::addRoute('LandingPageLoad', 'MainPageCtrl');
Utils::addRoute('GoToLoginPage', 'MainPageCtrl');

Utils::addRoute('login', 'LoginCtrl');
Utils::addRoute('logout', 'LoginCtrl');
Utils::addRoute('HomePageAfterLogin', 'MainPageCtrl',['ADMIN','USER']);
Utils::addRoute('register', 'RegisterCtrl');
Utils::addRoute('loginAfterRegister', 'LoginCtrl');
Utils::addRoute('showdescriptionforuser', 'ProfileCtrl');
Utils::addRoute('personEdit', 'ProfileCtrl');
Utils::addRoute('insertMoney', 'ProfileCtrl');
Utils::addRoute('moneyWithdraw', 'ProfileCtrl');
Utils::addRoute('beforeStartStatus', 'BetPrizeCtrl');
Utils::addRoute('chooseTheWinner', 'BetPrizeCtrl');
//Utils::addRoute('action_name', 'controller_class_name');
