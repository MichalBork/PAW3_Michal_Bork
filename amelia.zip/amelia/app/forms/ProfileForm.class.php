<?php

namespace app\forms;

class ProfileForm {
	public $idosby;
	public $imie;
	public $nazwisko;
	public $pesel;
	public $login;
	public $haslo;
	public $haslorepeat;
	public $miejscowosc;
	public $ulica;
	public $nrdomu;
	public $nrmieszkania;
	public $kodpocztowy;
	public $description;
	public $payment;
}