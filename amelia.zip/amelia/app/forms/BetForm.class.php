<?php

namespace app\forms;

class BetForm {
	public $money;
	public $player;
	public $score;
}