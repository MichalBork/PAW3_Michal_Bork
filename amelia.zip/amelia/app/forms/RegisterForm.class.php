<?php

namespace app\forms;

class RegisterForm {
	public $idosby;
	public $imie;
	public $nazwisko;
	public $pesel;
	public $login;
	public $haslo;
	public $haslorepeat;
	public $miejscowosc;
	public $ulica;
	public $nrdomu;
	public $nrmieszkania;
	public $kodpocztowy;
}