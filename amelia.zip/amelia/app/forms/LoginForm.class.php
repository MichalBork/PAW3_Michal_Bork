<?php

namespace app\forms;

class LoginForm {
	public $login;
	public $password;
	public $passwordfromdatabase;
}