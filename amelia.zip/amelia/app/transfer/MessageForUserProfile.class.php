<?php
namespace app\transfer;

class MessageForUserProfile
{
public $update;

}