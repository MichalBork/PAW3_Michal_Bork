<?php


namespace app\transfer;


use core\App;
use core\SessionUtils;

class InfoAboutCurrentUser
{
        public $currentusername;

}